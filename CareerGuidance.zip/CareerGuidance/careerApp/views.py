from django.shortcuts import render,HttpResponse,redirect,get_object_or_404
from .models import *
from django.db.models import Q
from django.contrib import messages
from django.contrib.auth import authenticate
from datetime import date,datetime,timedelta
from django.contrib.auth import logout
from django.utils.timezone import now

# Create your views here.
today = date.today()




def index(request):
    return render(request,'index.html')

def about(request):
    return render(request,'about.html')


def user_login(request):
    return render(request,'login.html')


def user_registration(request):
    return render(request,'user_registration.html')


def com_reg(request):
    return render(request,'com_reg.html')


def staff_reg(request):
    if 'aname' not in request.session:
        return redirect('user_login')
    return render(request, 'master/staff_reg.html')



def login_action(request):
    u = request.POST.get("username")
    p = request.POST.get("password")
    obj = authenticate(username=u, password=p)

    if obj is not None:
        if obj.is_superuser == 1:
            # Admin
            request.session['aname'] = u
            request.session['slogid'] = obj.id
            return redirect('admin_home')
        else:
            # Invalid user for non-admin
            messages.add_message(request, messages.INFO, 'Invalid User.')
            return redirect('user_login')
    else:
        newp = p
        try:
            obj1 = Login.objects.get(username=u, password=newp)

            if obj1.Usertype == "User":
                # User
                if obj1.status == "Approved":
                    request.session['uname'] = u
                    request.session['slogid'] = obj1.login_id
                    return redirect('user_home')
                elif obj1.status == "Not Approved":
                    messages.add_message(request, messages.INFO, 'Waiting For Approval.')
                    return redirect('user_login')
                else:
                    messages.add_message(request, messages.INFO, 'Invalid User.')
                    return redirect('user_login')

            elif obj1.Usertype == "Staff":
                # Staff
                if obj1.status == "Approved":
                    request.session['sname'] = u
                    request.session['slogid'] = obj1.login_id
                    return redirect('staff_home')
                elif obj1.status == "Not Approved":
                    messages.add_message(request, messages.INFO, 'Waiting For Approval.')
                    return redirect('user_login')
                else:
                    messages.add_message(request, messages.INFO, 'Invalid User.')
                    return redirect('user_login')

            elif obj1.Usertype == "Company":
                # Company
                if obj1.status == "Approved":
                    request.session['cname'] = u
                    request.session['slogid'] = obj1.login_id
                    return redirect('company_home')
                elif obj1.status == "Not Approved":
                    messages.add_message(request, messages.INFO, 'Waiting For Approval.')
                    return redirect('user_login')
                else:
                    messages.add_message(request, messages.INFO, 'Invalid User.')
                    return redirect('user_login')

            else:
                messages.add_message(request, messages.INFO, 'Invalid User.')
                return redirect('user_login')

        except Login.DoesNotExist:
            messages.add_message(request, messages.INFO, 'Invalid User.')
            return redirect('user_login')
        


        
def user_action(request):
    username = request.POST.get("username")
    data = {
       'username_exists': Login.objects.filter(username=username).exists(),
       'error': "Username Already Exists"
    }

    if data["username_exists"] == False:
        # Register User
        tbl1 = Login()
        tbl1.username = username
        tbl1.password = request.POST.get("password")
        tbl1.Usertype = "User"
        tbl1.status = "Approved"
        tbl1.save()

        # Create UserRegister record
        obj = Login.objects.get(username=username, password=tbl1.password)
        u = UserRegister()
        u.login_id = obj.login_id
        u.Name = request.POST.get("Name")
        u.phone_number = request.POST.get("phone")
        u.Email = request.POST.get("Email")
        u.Address = request.POST.get("Address")
        u.qualification = request.POST.get("qualification")
        u.save()

        messages.add_message(request, messages.INFO, 'User Registered successfully.')
        return redirect('user_registration')
    else:
        messages.add_message(request, messages.INFO, 'Username already exists. Registration failed.')
        return redirect('user_registration')


def staff_action(request):
    username = request.POST.get("username")
    data = {
       'username_exists': Login.objects.filter(username=username).exists(),
       'error': "Username Already Exists"
    }

    if data["username_exists"] == False:
        # Register Staff
        tbl1 = Login()
        tbl1.username = username
        tbl1.password = request.POST.get("password")
        tbl1.Usertype = "Staff"
        tbl1.status = "Approved"  
        tbl1.save()

        obj = Login.objects.get(username=username, password=tbl1.password)
        s = StaffRegister()  
        s.login_id = obj.login_id
        s.Name = request.POST.get("Name")
        s.phone_number = request.POST.get("phone")
        s.Email = request.POST.get("Email")
        s.Address = request.POST.get("Address")
        s.status = "Available"  
        s.save()

        messages.add_message(request, messages.INFO, 'Staff Registered successfully.')
        return redirect('staff_reg')
    else:
        messages.add_message(request, messages.INFO, 'Username already exists. Registration failed.')
        return redirect('staff_reg')




def company_action(request):
    username = request.POST.get("username")
    data = {
       'username_exists': Login.objects.filter(username=username).exists(),
       'error': "Username Already Exists"
    }

    if data["username_exists"] == False:
        # Register Company
        tbl1 = Login()
        tbl1.username = username
        tbl1.password = request.POST.get("password")
        tbl1.Usertype = "Company"
        tbl1.status = "Not Approved"  
        tbl1.save()

        try:
            obj = Login.objects.get(username=username, password=tbl1.password)

            c = CompanyRegister() 
            c.login = obj 
            c.CompanyName = request.POST.get("CompanyName")
            c.industry = request.POST.get("industry")
            c.phone_number = request.POST.get("phone")
            c.Email = request.POST.get("Email")
            c.Address = request.POST.get("Address")
            c.save()

            messages.add_message(request, messages.INFO, 'Company Registered successfully.')
            return redirect('com_reg')

        except Login.DoesNotExist:
            messages.add_message(request, messages.ERROR, 'Login registration failed. Please try again.')
            return redirect('com_reg')

    else:
        messages.add_message(request, messages.INFO, 'Username already exists. Registration failed.')
        return redirect('com_reg')
    


def admin_home(request):
    if 'aname' in request.session:
     program=Careerprogram.objects.all()
     
     return render(request,'Master/index.html',{'program':program})
    else:
      return redirect('user_login')
    

def user_home(request):
    if 'uname' in request.session:
        data=UserRegister.objects.get(login_id= request.session['slogid'])
        request.session['user_id']=data.user_id
        program=Careerprogram.objects.all()

        return render(request,'user/index.html',{'program':program})
    else:
      return redirect('user_login') 
    

def staff_home(request):
    if 'sname' in request.session:
        staff_data = StaffRegister.objects.get(login_id=request.session['slogid'])
        request.session['staff_id'] = staff_data.staff_id
        return render(request, 'staff/index.html', {'staff': staff_data})  
    else:
        return redirect('user_login') 

def company_home(request):
    if 'cname' in request.session: 
        company_data = CompanyRegister.objects.get(login_id=request.session['slogid'])
        request.session['company_id'] = company_data.company_id
        return render(request, 'company/index.html', {'company': company_data}) 
    else:
        return redirect('company_login') 


def common_logout(request):
    logout(request)
    request.session.delete()
    return redirect('user_login')


def user_profile(request):
    if 'uname' not in request.session:
        return redirect('user_login')

    log_id = request.session['slogid']
    try:
        user = UserRegister.objects.get(login_id=log_id)

        if request.method == 'POST':
            user.Name = request.POST.get("Name")
            user.Email = request.POST.get("Email")
            user.phone_number = request.POST.get("phone_number")
            user.Address = request.POST.get("Address")
            user.qualification = request.POST.get("qualification")
            user.save()
            messages.success(request, 'Profile updated successfully!')
            return redirect('user_profile')

        return render(request, 'user/user_profile.html', {'data': user})

    except UserRegister.DoesNotExist:
        messages.error(request, 'user not found')
        return redirect('user_login')



def approve_company(request):
    if 'aname' not in request.session:
        return redirect('user_login')

    company = CompanyRegister.objects.filter(login__status='Not Approved')

    if request.method == 'POST':
        company_id = request.POST.get('company_id')
        action = request.POST.get('action')

        hotel_to_update = CompanyRegister.objects.get(company_id=company_id)
        login_to_update = hotel_to_update.login
        
        if action == 'Approved':
                login_to_update.status = 'Approved'
                login_to_update.save()  
        elif action == 'Rejected':
                login_to_update.status = 'Rejected'
                login_to_update.save()  
        return redirect('approve_company') 
        
    return render(request, 'master/new_company.html', {'company': company})



def approved(request):
    if 'aname' not in request.session:
        return redirect('user_login')

    company = CompanyRegister.objects.filter(login__status='Approved')
    return render(request, 'master/approved.html', {'company': company})


def staff_list(request):
    if 'aname' in request.session:
     data=StaffRegister.objects.all()
     return render(request,'Master/staff_list.html',{'data':data})
    else:
      return redirect('user_login')   
    

def delete_staff(request):
   if 'aname' in request.session:
         if "login_id" in request.GET:
            try:
                obj=Login.objects.get(login_id=request.GET.get("login_id"))
                obj.delete()
                messages.success(request,'Deleted successfull')
                return redirect('staff_list')
            except Exception:
                return redirect('staff_list')
         else:
                return redirect('staff_list')
   else:
      return redirect('user_login')




def add_job(request):
    if 'cname' not in request.session:
        return redirect('user_login')
    if request.method == 'POST':
        title = request.POST.get('title')
        description = request.POST.get('description')
        company =CompanyRegister.objects.get(login_id=request.session['slogid'])
        location = request.POST.get('location')
        job_type = request.POST.get('job_type')
        status = 'Avilable'

        job_post = JobPost(
            title=title,
            description=description,
            company=company,
            location=location,
            job_type=job_type,
            status=status
        )
        job_post.save()
        messages.add_message(request, messages.INFO, 'Job Posted Successfully')

        return redirect('add_job') 

    return render(request, 'company/post_job.html')



def list_job(request):
    if 'cname' not in request.session:
        return redirect('user_login')
    company = get_object_or_404(CompanyRegister, login_id=request.session['slogid'])
    jobs=JobPost.objects.filter(company=company)
    return render(request, 'company/list_job.html',{'jobs':jobs})


def delete_job(request):
    if 'cname' not in request.session:
        return redirect('user_login')

    jobs=JobPost.objects.get(job_id=request.GET.get("job_id"))
    jobs.delete()
    messages.add_message(request, messages.INFO, 'Job deleted Successfully')

    return redirect('list_job')


def update_job(request):
    if 'cname' not in request.session:
        return redirect('user_login')

   
    job=JobPost.objects.get(job_id=request.GET.get("job_id"))
    return render(request, 'company/edit_job.html', {'job': job})



def edit_job(request):
    if 'cname' not in request.session:
        return redirect('user_login')

    if request.method == 'POST':
        job=JobPost.objects.get(job_id=request.POST.get("job_id"))
        job.title = request.POST.get('title')
        job.description = request.POST.get('description')
        job.company = CompanyRegister.objects.get(login_id=request.session['slogid'])
        job.location = request.POST.get('location')
        job.job_type = request.POST.get('job_type')
        job.status = 'Available' 
        job.save()

       
        messages.add_message(request, messages.INFO, 'Job Updated Successfully')
        return redirect('list_job')

    return render(request, 'company/edit_job.html')


def view_job(request):
    if 'uname' not in request.session:
        return redirect('user_login')

    jobs=JobPost.objects.all()
    return render(request, 'user/jobs.html',{'jobs':jobs})



def apply_job(request):
    if 'uname' not in request.session:  
        return redirect('user_login')  
    data=JobPost.objects.get(job_id=request.GET.get('job_id'))
    return render(request, 'user/apply_job.html',{'data':data})


def apply(request):
    if 'uname' not in request.session:  
        return redirect('user_login') 
    
    user = get_object_or_404(UserRegister, login_id=request.session['slogid'])
    
    job_id = request.GET.get('job_id')
    if not job_id:
        messages.add_message(request, messages.ERROR, 'Job ID is missing.')
        return redirect('view_job') 

    job_data = get_object_or_404(JobPost, job_id=job_id) 
    
    if Applyjob.objects.filter(job=job_data, user=user).exists():
        messages.add_message(request, messages.WARNING, 'You have already applied for this job.')
        return redirect('view_job')

    

    obj = Applyjob()
    obj.job = job_data
    obj.user = user
    obj.save()
    
    messages.add_message(request, messages.SUCCESS, 'Applied Successfully.')
    return redirect('view_job')


def applications(request):
    if 'cname' not in request.session:  
        return redirect('user_login') 
    company = get_object_or_404(CompanyRegister, login_id=request.session['slogid'])

    data = Applyjob.objects.filter(job__company=company)
    return render(request, 'company/applications.html', {'data': data})



def editstaff_profile(request):
    if 'sname' not in request.session:  
        return redirect('user_login') 
    staff = get_object_or_404(StaffRegister, login_id=request.session['slogid'])

    return render(request, 'staff/profile.html', {'staff': staff})



def updatestaff_profile(request):
    if 'sname' not in request.session:  
        return redirect('user_login') 
    s = StaffRegister.objects.get(staff_id=request.POST.get('staff_id'))  
    s.Name = request.POST.get("Name")
    s.phone_number = request.POST.get("phone")
    s.Email = request.POST.get("Email")
    s.Address = request.POST.get("Address")
    s.status = request.POST.get("status")
    s.save()
    return redirect('editstaff_profile')


def stafflist(request):
    if 'uname' not in request.session:  
        return redirect('user_login')  
    data=StaffRegister.objects.all()
    return render(request, 'user/stafflist.html',{'data':data})



def advice(request):
    if 'uname' not in request.session:
        return redirect('user_login')
    user=UserRegister.objects.get(login_id= request.session['slogid'])
    if request.method=='POST':

        advice = request.POST.get('advice')

        staff_id = request.POST.get("staff_id")

        staff = get_object_or_404(StaffRegister, staff_id=staff_id)
        
        Advice.objects.create(
            user=user, 
            staff=staff,
            advice=advice,
        )
        messages.success(request, "Consultation request submitted successfully!")
        return redirect('stafflist')
    data=StaffRegister.objects.get(staff_id=request.GET.get('staff_id'))
    return render(request, 'user/consult.html', {'data': data})

def consult_history_user(request):
    if 'uname' not in request.session:
        return redirect('user_login')
    user=UserRegister.objects.get(login_id= request.session['slogid'])
    data=Advice.objects.filter(user=user)
    return render(request, 'user/consult_history.html', {'data': data})

    


def consult_view(request):
    if 'sname' not in request.session:
        return redirect('user_login')

    staff = StaffRegister.objects.get(login_id=request.session['slogid'])
    data = Advice.objects.filter(staff=staff, reply__isnull=True)

    if request.method == 'POST':
        advice_id = request.POST.get('advice_id')
        reply = request.POST.get('reply')

        if not advice_id or not reply:
            messages.error(request, "Invalid request. Missing advice ID or reply content.")
            return render(request, 'staff/new_consult.html', {'data': data})

        try:
            obj = Advice.objects.get(advice_id=advice_id)
        except Advice.DoesNotExist:
            messages.error(request, "Advice not found.")
            return render(request, 'staff/new_consult.html', {'data': data})

        obj.reply = reply
        obj.save()
        messages.success(request, "Reply submitted successfully!")
        return redirect('consult_view')

    return render(request, 'staff/new_consult.html', {'data': data})




def consult_history(request):
    if 'sname' not in request.session:
        return redirect('user_login')

    staff = StaffRegister.objects.get(login_id=request.session['slogid'])
    data = Advice.objects.filter(staff=staff).exclude(reply__isnull=True)

    return render(request, 'staff/consult_history.html', {'data': data})


def skill_finding(request):
    if 'uname' not in request.session:
        return redirect('user_login')

    return render(request, 'user/skill.html')



from django.shortcuts import render
from django.http import HttpResponse

def calculate_skills(request):
    if request.method == "POST":
        answers = {
            "q1": request.POST.get('q1', '0'),
            "q2": request.POST.get('q2', '0'),
            "q3": request.POST.get('q3', '0'),
            "q4": request.POST.get('q4', '0'),
            "q5": request.POST.get('q5', '0'),
            "q6": request.POST.get('q6', '0'),
            "q7": request.POST.get('q7', '0'),
            "q8": request.POST.get('q8', '0'),
            "q9": request.POST.get('q9', '0'),
            "q10": request.POST.get('q10', '0'),
        }

        score = 0
        for answer in answers.values():
            score += int(answer)

        # Maximum score is 30 (since each question has a max value of 3, and there are 10 questions)
        max_score = 30

        # Initialize the skills dictionary with 0 percentage for each skill
        percentages = {
            "analytical": 0,
            "creative": 0,
            "problem_solving": 0,
            "leadership": 0,
        }

        # Distribute the score across the skills and calculate their percentages
        if score <= 15:
            percentages["analytical"] = (score / max_score) * 100
        elif score <= 25:
            percentages["creative"] = ((score - 15) / (max_score - 15)) * 100
        elif score <= 35:
            percentages["problem_solving"] = ((score - 25) / (max_score - 25)) * 100
        else:
            percentages["leadership"] = ((score - 35) / (max_score - 35)) * 100

        # Return the percentages to the result page
        return render(request, 'user/result.html', {
            'percentages': percentages,
            'score': score,
            'max_score': max_score,
        })

    return HttpResponse("Invalid request method", status=400)




def feedback(request):
    if 'uname' not in request.session:
        return redirect('user_login')  # Redirect to login if the session does not contain 'uname'

    try:
        user = UserRegister.objects.get(login_id=request.session['slogid'])
    except UserRegister.DoesNotExist:
        messages.error(request, "User not found.")
        return redirect('user_login')

    if request.method == 'POST':
        feedback_text = request.POST.get("feedback")
        if feedback_text:
            # Create a new feedback entry
            Feedback.objects.create(
                feedback=feedback_text,
                date=now(),
                user=user
            )
            messages.success(request, 'Feedback submitted successfully!')
            return redirect('feedback')  # Redirect to avoid re-submission on refresh
        else:
            messages.error(request, 'Feedback cannot be empty!')

    data = Feedback.objects.filter(user=user).order_by('-date') 
    return render(request, 'user/feedback.html', {'data': data})


def reply_feedback(request):
    if 'aname' in request.session:
        if request.method == 'POST':
            fd_id = request.POST.get('fd_id')
            reply = request.POST.get('reply')
            
            Feedback.objects.filter(fd_id=fd_id).update(reply=reply)
            messages.success(request, 'Reply submitted successfully.')
            return redirect('reply_feedback') 
            
        else:
            data = Feedback.objects.all() 
            return render(request, 'master/feedback_view.html', {'data': data})
    else:
        return redirect('user_home')
    


def applications(request):
    if 'cname' not in request.session:  
        return redirect('user_login') 
    company = get_object_or_404(CompanyRegister, login_id=request.session['slogid'])

    if request.method == 'POST':
        applyjob_id = request.POST.get('applyjob_id')
        action = request.POST.get('action')
        application = get_object_or_404(Applyjob, job_id__company=company, applyjob_id=applyjob_id)

        if action == 'approve':
            application.status = 'approved'
            messages.add_message(request, messages.SUCCESS, f'Application for {application.job.title} has been approved successfully.')
        elif action == 'reject':
            application.status = 'rejected'
            messages.add_message(request, messages.WARNING, f'Application for {application.job.title} has been rejected.')
        
        application.save()

    data = Applyjob.objects.filter(job_id__company=company, status__isnull=True)
    return render(request, 'company/applications.html', {'data': data})



def history(request):
    if 'cname' not in request.session:  
        return redirect('user_login') 
    company = get_object_or_404(CompanyRegister, login_id=request.session['slogid'])
    data = Applyjob.objects.filter(job_id__company=company, status__isnull=False)
    return render(request, 'company/history.html', {'data': data})


def job_status(request):
    if 'uname' not in request.session:  
        return redirect('user_login') 
    user = UserRegister.objects.get(login_id=request.session['slogid'])
    data = Applyjob.objects.filter(user=user, status='approved')
    return render(request, 'user/job_status.html', {'data': data})




def add_program(request):
    if 'sname' not in request.session:
        return redirect('user_login')

    if request.method == 'POST':
        title = request.POST.get('title')
        description = request.POST.get('description')
        staff = StaffRegister.objects.get(login_id=request.session['slogid'])  
        place = request.POST.get('place')
        date =  request.POST.get('date')

        career_program = Careerprogram(
            title=title,
            description=description,
            staff=staff,
            place=place,
            date=date
        )
        career_program.save()

        messages.add_message(request, messages.INFO, 'Program Posted Successfully')

        return redirect('add_program')

    return render(request, 'staff/add_program.html')




def list_program(request):
    if 'sname' not in request.session:
        return redirect('user_login')
    staff = get_object_or_404(StaffRegister, login_id=request.session['slogid'])
    program=Careerprogram.objects.filter(staff=staff)
    return render(request, 'staff/list_program.html',{'program':program})


def delete_program(request):
    if 'sname' not in request.session:
        return redirect('user_login')

    program=Careerprogram.objects.get(program_id=request.GET.get("program_id"))
    program.delete()
    messages.add_message(request, messages.INFO, 'program deleted Successfully')

    return redirect('list_program')


# views.py

# views.py



def add_category(request):
    message = ""
    if request.method == 'POST':
        name = request.POST.get('name', '').strip()
        if name:
            if Category.objects.filter(name__iexact=name).exists():
                message = "Category already exists."
            else:
                Category.objects.create(name=name)
                message = "Category added successfully!"
        else:
            message = "Category name is required."

    categories = Category.objects.all()
    return render(request, 'master/add_category.html', {
        'categories': categories,
        'message': message
    })


from .models import Question, Category

def test(request):
    categories = Category.objects.all()
    selected_category_id = request.POST.get('category') or request.GET.get('category')

    if selected_category_id:
        selected_category = Category.objects.get(id=selected_category_id)
        existing_questions = Question.objects.filter(category=selected_category)

        if request.method == 'POST' and 'submit_questions' in request.POST:
            if existing_questions.count() >= 10:
                return render(request, 'master/aptitude_test.html', {
                    'categories': categories,
                    'selected_category': selected_category,
                    'already_added': True,
                    'existing_questions': existing_questions
                })

            for i in range(1, 11):
                text = request.POST.get(f'question_{i}', '').strip()
                if text:
                    Question.objects.create(category=selected_category, question_text=text)
            messages.add_message(request, messages.INFO, 'Added Successfully')
            return redirect('test')  # reload page

        if request.method == 'POST' and 'delete_all' in request.POST:
            existing_questions.delete()
            return redirect(f'/test/?category={selected_category_id}')

        return render(request, 'master/aptitude_test.html', {
            'categories': categories,
            'selected_category': selected_category,
            'existing_questions': existing_questions,
            'already_added': existing_questions.count() >= 10,
            'question_range': range(1, 11)
        })

    return render(request, 'master/aptitude_test.html', {'categories': categories})


# views.py


def student_take_test(request):
    categories = Category.objects.all()
    selected_category_id = request.GET.get('category')
    questions = []

    if selected_category_id:
        selected_category = Category.objects.get(id=selected_category_id)
        questions = Question.objects.filter(category=selected_category)[:10]

        if request.method == 'POST':
            # Check if already submitted for this category
            if TestSubmission.objects.filter(student=UserRegister.objects.get(login_id=request.session['slogid']), category=selected_category).exists():
                return HttpResponse('already_submitted')

            submission = TestSubmission.objects.create(student=UserRegister.objects.get(login_id=request.session['slogid']), category=selected_category)
            for question in questions:
                answer = request.POST.get(f'question_{question.id}', '').strip()
                Answer.objects.create(submission=submission, question=question, answer_text=answer)
            return redirect('student_take_test')

        return render(request, 'user/take_test.html', {
            'questions': questions,
            'category': selected_category
        })

    return render(request, 'user/select_category.html', {
        'categories': categories
    })




def submission_list(request):
    submissions = TestSubmission.objects.select_related('student', 'category').order_by('-submitted_at')
    return render(request, 'master/submission_list.html', {'submissions': submissions})


def review_submission(request, submission_id):
    submission = TestSubmission.objects.get(id=submission_id)
    answers = submission.answers.select_related('question')

    if request.method == 'POST':
        submission.result = request.POST.get('result')
        submission.message = request.POST.get('message')
        submission.reviewed = True
        submission.save()
        return redirect('submission_list')

    return render(request, 'master/review_submission.html', {
        'submission': submission,
        'answers': answers
    })





def view_results(request):
    submissions = TestSubmission.objects.filter(student=UserRegister.objects.get(login_id=request.session['slogid']), reviewed=True).select_related('category')
    return render(request, 'user/view_results.html', {'submissions': submissions})
