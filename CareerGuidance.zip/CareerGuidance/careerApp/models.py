from django.db import models

# Login Model (Common to all users, staff, and company)
class Login(models.Model):
    login_id = models.AutoField(primary_key=True)
    username = models.CharField(max_length=50)
    password = models.TextField()
    Usertype = models.CharField(max_length=50)
    status = models.CharField(max_length=50)

    class Meta:
        db_table = 'tbl_login'


# User Registration Model
class UserRegister(models.Model):
    user_id = models.AutoField(primary_key=True)
    login = models.ForeignKey(Login, on_delete=models.CASCADE)
    Name = models.CharField(max_length=50)
    phone_number = models.BigIntegerField(null=True)
    Email = models.EmailField(max_length=50)
    Address = models.TextField()
    qualification = models.CharField(max_length=100, null=True, blank=True)  # Added Qualification

    class Meta:
        db_table = 'tbl_user_register'


# Staff Registration Model
class StaffRegister(models.Model):
    staff_id = models.AutoField(primary_key=True)
    login = models.ForeignKey(Login, on_delete=models.CASCADE)
    Name = models.CharField(max_length=50)
    phone_number = models.BigIntegerField(null=True)
    Email = models.EmailField(max_length=50)
    Address = models.TextField()
    status = models.CharField(max_length=50,null=True)

    class Meta:
        db_table = 'tbl_staff_register'


# Company Registration Model
class CompanyRegister(models.Model):
    company_id = models.AutoField(primary_key=True)
    login = models.ForeignKey(Login, on_delete=models.CASCADE)
    CompanyName = models.CharField(max_length=100)
    industry = models.CharField(max_length=100)
    phone_number = models.BigIntegerField()
    Email = models.EmailField(max_length=50)
    Address = models.TextField()

    class Meta:
        db_table = 'tbl_company_register'


# Job Post Model 
class JobPost(models.Model):
    job_id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=255)
    description = models.TextField()
    company = models.ForeignKey(CompanyRegister, on_delete=models.CASCADE)
    location = models.CharField(max_length=255)
    job_type = models.CharField(max_length=50)  
    status = models.CharField(max_length=55)

    class Meta:
        db_table = 'tbl_job'


# Job Application Model
class Applyjob(models.Model):
    applyjob_id = models.AutoField(primary_key=True)
    user = models.ForeignKey(UserRegister, on_delete=models.CASCADE)
    job = models.ForeignKey(JobPost, on_delete=models.CASCADE)
    status = models.CharField(max_length=55,null=True)

    class Meta:
        db_table = 'tbl_jobApply'


# Advice Model 
class Advice(models.Model):
    advice_id = models.AutoField(primary_key=True)
    user = models.ForeignKey(UserRegister, on_delete=models.CASCADE,null=True)
    staff = models.ForeignKey(StaffRegister, on_delete=models.CASCADE,null=True)
    advice = models.TextField()
    reply = models.TextField(null=True, blank=True)

    class Meta:
        db_table = 'tbl_advice'


# Feedback Model
class Feedback(models.Model):
    fd_id = models.AutoField(primary_key=True)
    user = models.ForeignKey(UserRegister, on_delete=models.CASCADE)
    date = models.DateTimeField(auto_now_add=True)
    feedback = models.TextField()
    reply = models.TextField(null=True, blank=True)

    class Meta:
        db_table = 'tbl_feedback'


class Careerprogram(models.Model):
    program_id = models.AutoField(primary_key=True)
    staff = models.ForeignKey(StaffRegister, on_delete=models.CASCADE,null=True)
    title = models.CharField(max_length=255)
    date = models.DateTimeField()
    description = models.TextField()
    place = models.TextField(null=True, blank=True)

    class Meta:
        db_table = 'tbl_Careerprogram'


# models.py




class Category(models.Model):
    name = models.CharField(max_length=100, unique=True)
    class Meta:
        db_table = 'tbl_Category'

    def __str__(self):
        return self.name


class Question(models.Model):
    category = models.ForeignKey(Category, on_delete=models.CASCADE)
    question_text = models.TextField()
    class Meta:
        db_table = 'tbl_question'

    def __str__(self):
        return f"{self.category.name} - {self.question_text[:50]}"




class TestSubmission(models.Model):
    student = models.ForeignKey(UserRegister, on_delete=models.CASCADE)
    category = models.ForeignKey(Category, on_delete=models.CASCADE)
    submitted_at = models.DateTimeField(auto_now_add=True)
    reviewed = models.BooleanField(default=False)
    result = models.CharField(max_length=100, blank=True, null=True)
    message = models.TextField(blank=True, null=True)

    def __str__(self):
        return f"{self.student.username} - {self.category.name}"


class Answer(models.Model):
    submission = models.ForeignKey(TestSubmission, on_delete=models.CASCADE, related_name='answers')
    question = models.ForeignKey(Question, on_delete=models.CASCADE)
    answer_text = models.TextField()

    def __str__(self):
        return f"{self.submission.student.username}'s Answer to Q{self.question.id}"