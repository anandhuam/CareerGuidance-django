"""
URL configuration for cleaning_management project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from .import views

urlpatterns = [
    path('',views.index,name="index"),
    path('index/',views.index,name="index"),
    path('about/',views.about,name="about"),
    path("user_login/",views.user_login,name="user_login"),
    path("user_registration/",views.user_registration,name="user_registration"),
    path("com_reg/",views.com_reg,name="com_reg"),
    path("login_action/",views.login_action,name="login_action"),
    path("user_action/",views.user_action,name="user_action"),
    path("company_action/",views.company_action,name="company_action"),
    path("admin_home/",views.admin_home,name="admin_home"),
    path("user_home/",views.user_home,name="user_home"),
    path("staff_home/",views.staff_home,name="staff_home"),
    path("company_home/",views.company_home,name="company_home"),
    path("common_logout/",views.common_logout,name="common_logout"),

    # Admin
    path("approve_company/",views.approve_company,name="approve_company"),
    path("approved/",views.approved,name="approved"),
    path("staff_reg/",views.staff_reg,name="staff_reg"),
    path("staff_action/",views.staff_action,name="staff_action"),
    path('reply_feedback/', views.reply_feedback, name='reply_feedback'),
    path('staff_list/', views.staff_list, name='staff_list'),
    path('delete_staff/', views.delete_staff, name='delete_staff'),
    path('test/', views.test, name='test'),
    path('add-category/', views.add_category, name='add_category'),
    path('student_take_test/', views.student_take_test, name='student_take_test'),
    path('submissions/', views.submission_list, name='submission_list'),
     path('submission/<int:submission_id>/review/', views.review_submission, name='review_submission'),







     # company
    path("add_job/",views.add_job,name="add_job"),
    path("list_job/",views.list_job,name="list_job"),
    path("delete_job/",views.delete_job,name="delete_job"),
    path("update_job/",views.update_job,name="update_job"),
    path("edit_job/",views.edit_job,name="edit_job"),
    path("applications/",views.applications,name="applications"),
    path("history/",views.history,name="history"),






    #user
    path("view_job/",views.view_job,name="view_job"),
    path("apply_job/",views.apply_job,name="apply_job"),
    path("apply/",views.apply,name="apply"),
    path("stafflist/",views.stafflist,name="stafflist"),
    path("advice/",views.advice,name="advice"),
    path("consult_history_user/",views.consult_history_user,name="consult_history_user"),
    path('skill_finding/', views.skill_finding, name='skill_finding'),
    path('calculate_skills/', views.calculate_skills, name='calculate_skills'),
    path('user_profile/', views.user_profile, name='user_profile'),
    path('feedback/', views.feedback, name='feedback'),
    path('job_status/', views.job_status, name='job_status'),
    path('view_results/', views.view_results, name='view_results'),





    #staff
    path("editstaff_profile/",views.editstaff_profile,name="editstaff_profile"),
    path("updatestaff_profile/",views.updatestaff_profile,name="updatestaff_profile"),
    path("consult_view/",views.consult_view,name="consult_view"),
    path("consult_history/",views.consult_history,name="consult_history"),
    path("add_program/",views.add_program,name="add_program"),
    path("list_program/",views.list_program,name="list_program"),
    path("delete_program/",views.delete_program,name="delete_program"),
   

  
   
   

  

   

    

]
